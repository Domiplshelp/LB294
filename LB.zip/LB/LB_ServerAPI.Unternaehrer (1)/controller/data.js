module.exports = {
  InitialData: [
    {
      Name: "John",
      Tier: "Elefant",
      Ort: "Ostfl�gel 3",
      Alter: "8",
      Futter: "Stroh",
      Beschrieb: "Hat ein Bein gebrochen",
    },
    {
      Name: "Cedric",
      Tier: "L�we",
      Ort: "Ostfl�gel 4",
      Alter: "6",
      Futter: "Frischfleisch",
      Beschrieb: "Ist top fit",
    },
    {
      Name: "Tom",
      Tier: "Papagei",
      Ort: "Ostfl�gel 7",
      Alter: "40",
      Futter: "K�rner und Fr�chte",
      Beschrieb: "Versucht dich zu �berreden in Bitcoin zu investieren",
    },
    {
      Name: "Kilian",
      Tier: "Clown Fisch",
      Ort: "Nordfl�gel 2",
      Alter: "2",
      Futter: "Algen und Fischfutter",
      Beschrieb: "Kann einen Kick Flip",
    }
  ]
};
