"use strict";
const homebtn = document.getElementById("homebtn");
const anmeldebtn = document.getElementById("anmeldebtn");
const header = document.getElementById("header");
const content = document.getElementById("content");
var inputBenutz;
var inputPass;
var tiere;
var Token;
var anmeldeButton;
homebtn.addEventListener("click", loadHome);
anmeldebtn.addEventListener("click", loadAnmelden);

fetch("http://localhost:3000/api/getall", {

    method: "GET"
})
.then((response) => {
    return response.json();
})
.then((jsonData) => {
    console.log(jsonData);
    tiere = jsonData;
});

function Anmelden(ev){
  ev.preventDefault();
  fetch("http://localhost:3000/user/login", {
    method: "POST",
    headers: {
        "content-type": "application/json",
        alg: "HS256",
        typ: "JWT"
    },
    body: JSON.stringify({
        username: inputBenutz.value,
        password: inputPass.value 
    }),
    
})
.then((response) => {
    return response.json();
})
.then((jsonData) => {
    console.log(jsonData);
    Token = jsonData.token;
    console.log(Token);
});
console.log(inputBenutz.value);
console.log(inputPass.value);

//passwort bestätigung kommt hier noch hin
}


function loadHome(ev) {
  ev.preventDefault();
  homebtn.className = "bold";
  anmeldebtn.className = "";
  var ul = document.createElement("ul");
  content.innerHTML = "";
  tiere.forEach(element => {
    const li = document.createElement("li");
    const p = document.createElement("p");
    const p2 = document.createElement("p");
    p.className = "listitems";
    p2.className = "listitems";
    li.className = "listcontetn";
    p.innerText = "Name: " + element.Name + "\n" + "Tier: " + element.Tier + "\n" + "Ort: " + element.Ort;
    p2.innerText = "Alter: " + element.Alter + "\n" + "Futter: " + element.Futter + "\n" + "Beschrieb: " + element.Beschrieb;
    li.append(p);
    li.append(p2);
    ul.append(li);
  });
  
  content.append(ul);
}

function loadAnmelden(ev){
  ev.preventDefault();
  content.innerHTML = "";
  homebtn.className = "";
  anmeldebtn.className = "bold";
  const p1 = document.createElement("p");
  inputBenutz = document.createElement("input");
  inputPass = document.createElement("input");
  anmeldeButton = document.createElement("button");
  anmeldeButton.addEventListener("click", Anmelden);
  const p2 = document.createElement("p");
  const p3 = document.createElement("p");
  const div = document.createElement("div");
  anmeldeButton.className = "bold";
  anmeldeButton.innerText = "Anmelden";
  div.className = "anmeldep";
  p1.className = "bold";
  p1.innerText = "Anmelden:";
  p2.innerText = "Benutzname:";
  p3.innerText = "Passwort";
  div.append(p1,p2,inputBenutz,p3,inputPass,anmeldeButton);
  content.append(div);
}
